package com.hcl.interviews;

import static com.hcl.interviews.support.BehaviouralTestEmbedder.aBehaviouralTestRunner;

import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;
import org.junit.Test;

/**
 * Acceptance test class that uses the JBehave (Gerkin) syntax for writing
 * stories. You will notice the TimeConverter has no implementation ... (hint)
 */
public class ReversePolishNotationFixture {

	String inputExpression = "";
	ReversePolishNotation reversePolishNotation=new ReversePolishNotation();

	@Test
	public void reversePolishNotationAcceptanceTests() throws Exception {
		aBehaviouralTestRunner().usingStepsFrom(this).withStory("reverse-polish-notation.story").run();
	}

	@When("reverse polish notation is $reversePolishNotation")
	public void whenInputIslimit(String inputExpression) {

		this.inputExpression = inputExpression;

	}

	@Then("the output should be $")
	public void thenTheOutputShouldBe(Double expectedOutput) {

	   Double result =ReversePolishNotation.calculateReversePolishNotation(inputExpression);
		Assert.assertEquals(expectedOutput, result);
	}

}

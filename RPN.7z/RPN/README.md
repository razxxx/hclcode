# Reverse Polish Notation

In reverse Polish notation the operators follow their operands; for instance, to add 3 and 4, one would write �3 4 +� rather than �3 + 4�. If there are 
multiple operations, the operator is given immediately after its second operand; so the expression written �3 � 4 + 5� in conventional notation would be 
written �3 4 � 5 +� in RPN: 4 is first subtracted from 3, then 5 added to it. 

## The brief
We have created a number of acceptance tests for the Reverse Polish Notation and your challenge is to get them passing. 
Additionally, please make sure your solution is accompanied by comments in any form that describe a step-by-step refactorings, 
so we can understand the way you were thinking.

## Some hints
Write your code in ReversePolishNotation.java, you can make other classes. But make sure they are called from ReversePolishNotation.java only.
Check ReversePolishNotationFixture.java for writing your test cases. You can uncomment that file and implement your test case.
If you are new to Gradle, it may be worth spending 10 minutes reading a high level summary.  We are using the Gradle
Wrapper so `gradlew` from the command line should download everything you need.  Most modern IDEs support Gradle projects.

The use of JBehave in this instance is to provide you with our definition of done for the task.